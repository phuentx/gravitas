-- AlterTable
ALTER TABLE `Post` ADD COLUMN `imgHeight` INTEGER NULL;
